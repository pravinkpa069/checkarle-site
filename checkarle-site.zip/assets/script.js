
(function(){
  const regionEl = document.getElementById('region');
  const styleEl = document.getElementById('style');
  const daysEl = document.getElementById('days');
  const peopleEl = document.getElementById('people');
  const flightEl = document.getElementById('flight');
  const bufferEl = document.getElementById('buffer');
  const resultEl = document.getElementById('result');
  const perPersonEl = document.getElementById('perPerson');
  const totalEl = document.getElementById('total');
  const breakdownList = document.getElementById('breakdownList');
  const shareUrl = document.getElementById('shareUrl');
  const copyBtn = document.getElementById('copyBtn');
  const year = document.getElementById('year');
  year.textContent = new Date().getFullYear();

  const styleBases = { backpacker: 2500, comfort: 5000, luxury: 12000 };
  const regionMult = { india:1.0, seasia:1.2, europe:2.0, americas:2.2, middleeast:1.6, africa:1.5, oceania:2.4 };

  // parse URL params to prefill
  const params = new URLSearchParams(location.search);
  if(params.has('region')) regionEl.value = params.get('region');
  if(params.has('style')) styleEl.value = params.get('style');
  if(params.has('days')) daysEl.value = +params.get('days') || 5;
  if(params.has('people')) peopleEl.value = +params.get('people') || 2;
  if(params.has('flight')) flightEl.value = +params.get('flight') || '';
  if(params.has('buffer')) bufferEl.value = params.get('buffer');

  function fmt(n){ return '₹' + (Math.round(n)).toLocaleString('en-IN'); }

  function calc(e){
    if(e) e.preventDefault();
    const region = regionEl.value;
    const style = styleEl.value;
    const days = Math.max(1, +daysEl.value || 1);
    const people = Math.max(1, +peopleEl.value || 1);
    const flight = Math.max(0, +flightEl.value || 0);
    const buffer = parseFloat(bufferEl.value);

    const base = styleBases[style] * (regionMult[region] || 1);
    const stay = base * 0.5 * days * people;
    const food = base * 0.3 * days * people;
    const local = base * 0.12 * days * people;
    const activities = base * 0.08 * days * people;
    const flights = flight * people;
    const subtotal = stay + food + local + activities + flights;
    const contingency = subtotal * buffer;
    const total = subtotal + contingency;
    const perPerson = total / people;

    perPersonEl.textContent = fmt(perPerson);
    totalEl.textContent = fmt(total);

    breakdownList.innerHTML = `
      <li>Stay: ${fmt(stay)}</li>
      <li>Food: ${fmt(food)}</li>
      <li>Local transport: ${fmt(local)}</li>
      <li>Activities buffer: ${fmt(activities)}</li>
      <li>Flights: ${fmt(flights)}</li>
      <li>Contingency (${Math.round(buffer*100)}%): ${fmt(contingency)}</li>
    `;

    // Set shareable URL
    const sp = new URLSearchParams({region, style, days, people, flight, buffer});
    const url = `${location.origin}${location.pathname}?${sp.toString()}`;
    shareUrl.value = url;

    resultEl.classList.remove('hidden');
  }

  document.getElementById('calcForm').addEventListener('submit', calc);
  copyBtn.addEventListener('click', () => {
    shareUrl.select();
    document.execCommand('copy');
    copyBtn.textContent = 'Copied!';
    setTimeout(()=>copyBtn.textContent='Copy link', 1200);
  });

  // auto-calc on load for better UX
  calc();
})();
